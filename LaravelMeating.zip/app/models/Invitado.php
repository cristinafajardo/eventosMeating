<?php 
class Invitado extends Eloquent { 
    protected $table = 'invitados';
	
	
	/*
	
	public function eventos()
	{
		return $this->hasMany('Evento');
	}*/
}
?>