<?php 
class Itemsok extends Eloquent { 
    protected $table = 'itemsoks';
	
	/*
	public function usuarios()
	{
	return $this->hasMany('Usuario'); // un articulo puede ser llevado por mucho usuarios
	
	}*/
	
	
	
	
	
	
}
?>