<?php 
class Foto extends Eloquent { 
    protected $table = 'fotos';
	
	
	/*
	public function eventos()
	{
		return $this->belongsTo('Evento','evento');
	}*/
	
}
?>