<div id="footer">
		<!-- FOOTER -->
        <footer id="mainFooter">
            <div class="wrapped" align="center"> <!--Anclamos un footer abajo del todo de la pagina-->
                <p class="pull-right"><a id="goTop" href="#"><h3> ^ </h3></a></p> <!--con ese icono nos lleva hacia arriba de la pagina-->
                <p>© 2014 MEating   ·  <a href="ruta de privacidad y terminos">Privacidad y Términos</a> · Seguinos en <!--nos va a llevar a los links mencionados abajo a traves de los iconos-imagenes-->
                	<a href="http://facebook.com"><img src="img/f1.png" height='30' width='70'></a> | 
					<a href="http://twitter.com"><img src="img/t1.png" height='30' width='70'></a> |
					<a href="http://plus.google.com/share"><img src="img/g1.png" height='30' width='70'></a>
					
                </p>
            </div>
        </footer>
 </div>