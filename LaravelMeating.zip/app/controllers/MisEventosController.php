<?php


class MisEventosController extends BaseController {
	public function index()
	{
		return View::make('eventos.MisEventos');
	}

}