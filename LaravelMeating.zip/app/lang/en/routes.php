<?php return array(
	'login' => 'login',
	'logout' => 'logout',
);