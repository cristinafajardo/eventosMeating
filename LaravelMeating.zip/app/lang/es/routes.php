<?php return array(
	'login' => 'acceder',
	'logout' => 'salir',
);